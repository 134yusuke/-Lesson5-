class HomesController < ApplicationController
  def top
  end
  
  def books
  end
  
  
end
